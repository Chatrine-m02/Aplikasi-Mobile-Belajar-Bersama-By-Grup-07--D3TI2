package stud11318057.develops.belber.constants;

public class Constants
{
    public static final String APP_LOG_NAME = "Belajar Bersama";

    public static final int MAX_QUESTIONS_PER_ROUND = 10;
}
